prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 102
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9517357508663646
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'RIJAD'
);
null;
wwv_flow_api.component_end;
end;
/
