prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9517357508663646
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'RIJAD'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(9848243714542386)
,p_name=>'Seite 3'
,p_alias=>'SEITE-3'
,p_step_title=>'Seite 3'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'RIJAD'
,p_last_upd_yyyymmddhh24miss=>'20210206171958'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19550689877849967)
,p_plug_name=>'Seite 3 - Organigramm'
,p_region_name=>'chart_div'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(9763037372542309)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'Htp.P(',
'q''[',
'<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>',
'<script type="text/javascript">',
'	google.charts.load(''current'', {packages:["orgchart"]});',
'	google.charts.setOnLoadCallback(drawChart);',
'',
'	function drawChart() {',
'		var data = new google.visualization.DataTable();',
'		data.addColumn(''string'', ''Name'');',
'		data.addColumn(''string'', ''Manager'');',
'		data.addColumn(''string'', ''ToolTip'');',
'',
'        data.addRows([',
']''',
');',
'',
'FOR c IN(',
'    select',
'        case lvl when 3 then lvl + ceil(rn/3) - 1 else lvl end as lvl,',
'        id,',
'        name,',
'        username,',
'        parent_id',
'    from',
'        (',
'            select',
'                level as lvl,',
'                id,',
'                name,',
'                username,',
'                parent_id,',
'                rownum as ord,',
'                row_number() over (partition by parent_id order by name) as rn',
'            from MITARBEITERS',
'            start with NVL(id, ''-1'') = NVL(:P3_START_WITH, ''-1'')',
'            connect by nocycle prior name = parent_id',
'        )',
'    order by ord',
')',
'LOOP',
'    --Htp.P(''[{''''v'''':'''''' || c.id || '''''', ''''f'''':'''''' || c.parent_id || ''<div style="color:red; font-style:italic">'' || c.parent_id || ''</div>''''},'''''''', '''''' || c.name || ''''''],'');',
'    Htp.P(''['''''' || c.name || '''''', '''''' || c.parent_id || '''''', '''''' || c.name || ''''''],'');',
'END LOOP;',
'		',
'',
'',
'Htp.P(',
'q''[',
'        ]);',
'',
'		var chart = new google.visualization.OrgChart(document.getElementById(''chart_div''));',
'		chart.draw(data, {''allowHtml'':true});',
'	}',
'</script>',
']''',
');',
'END;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19550896168849969)
,p_plug_name=>'Parameters'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(9763037372542309)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19551138253849972)
,p_plug_name=>'Starting point'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(9734629534542286)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    Htp.P(''<h3 style="font-weight:bold;">Starting point: '' || :P3_START_WITH || ''</h3>'');',
'END;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9873720843649963)
,p_name=>'P3_START_WITH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(19550896168849969)
,p_prompt=>'Start With'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    lpad(''-'',lvl*2,''-'')||name AS name,',
'    id',
'from',
'    (',
'        select',
'            level as lvl,',
'            id,',
'            name,',
'            username,',
'            parent_id,',
'            rownum as ord,',
'            row_number() over (partition by parent_id order by name) as rn',
'        from MITARBEITERS',
'        start with NVL(parent_id, ''-1'') = NVL(null, ''-1'')',
'        connect by nocycle prior name = parent_id',
'    )',
'order by ord'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(9824489665542362)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
