prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9517357508663646
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'RIJAD'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(9848243714542386)
,p_name=>'Seite 2'
,p_alias=>'SEITE-2'
,p_step_title=>'Seite 2'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#ERROR_MESSAGE{',
'    display:none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'RIJAD'
,p_last_upd_yyyymmddhh24miss=>'20210206171752'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9680546185200032)
,p_plug_name=>'Edit'
,p_region_name=>'EDIT_GRID'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(9763037372542309)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9681711552200044)
,p_plug_name=>'Error messages'
,p_region_name=>'ERROR_MESSAGE'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(9763037372542309)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19567139085067066)
,p_plug_name=>'Seite 2'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(9761148638542307)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID,',
'    NAME,',
'    STREET,',
'    PLZ,',
'    CITY',
'FROM MITARBEITERS',
'ORDER BY ID ASC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Seite 1'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(19567187879067067)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF:RTF:EMAIL'
,p_owner=>'RIJAD'
,p_internal_uid=>19567187879067067
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9889370230867051)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'#'
,p_column_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4:P4_EDIT_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9889701981867053)
,p_db_column_name=>'NAME'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9890169996867055)
,p_db_column_name=>'STREET'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>unistr('Stra\00DFe')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9890531601867055)
,p_db_column_name=>'PLZ'
,p_display_order=>80
,p_column_identifier=>'D'
,p_column_label=>'PLT'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9890905976867056)
,p_db_column_name=>'CITY'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Stadt'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(19753267929445504)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'98913'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NAME:STREET:PLZ:CITY'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(19747173962409478)
,p_plug_name=>'MTAG 2'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(9753460202542299)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(9681200044200039)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(9680546185200032)
,p_button_name=>'Save'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_api.id(9825591663542364)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
,p_grid_column_span=>6
,p_grid_column=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9680408237200031)
,p_name=>'P4_EDIT_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(9680546185200032)
,p_prompt=>'Edit ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_grid_column=>1
,p_field_template=>wwv_flow_api.id(9824489665542362)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9680806355200035)
,p_name=>'P4_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(9680546185200032)
,p_prompt=>'Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(9824489665542362)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9680992265200036)
,p_name=>'P4_STREET'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(9680546185200032)
,p_prompt=>unistr('Stra\00DFe')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>3
,p_grid_column=>1
,p_field_template=>wwv_flow_api.id(9824489665542362)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9681042867200037)
,p_name=>'P4_PLZ'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(9680546185200032)
,p_prompt=>'PLZ'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(9824489665542362)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9681130121200038)
,p_name=>'P4_CITY'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(9680546185200032)
,p_prompt=>'Stadt'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_column=>7
,p_field_template=>wwv_flow_api.id(9824489665542362)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(9681620547200043)
,p_name=>'P4_ERROR_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(9681711552200044)
,p_prompt=>'Error Message'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(9824489665542362)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9680630591200033)
,p_name=>'HideEdit'
,p_event_sequence=>10
,p_condition_element=>'P4_EDIT_ID'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9680782680200034)
,p_event_id=>wwv_flow_api.id(9680630591200033)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(9680546185200032)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9681497606200041)
,p_name=>'FetchData'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9681532682200042)
,p_event_id=>wwv_flow_api.id(9681497606200041)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_name VARCHAR2(128 CHAR);',
'    v_street VARCHAR2(128 CHAR);',
'    v_plz VARCHAR2(128 CHAR);',
'    v_city VARCHAR2(128 CHAR);',
'',
'    v_right_count INTEGER := 0;',
'BEGIN',
'    IF :P4_EDIT_ID IS NOT NULL THEN',
'        FOR exists_in IN(',
'            select',
'                id ',
'            from',
'                (',
'                    select',
'                        level as lvl,',
'                        id,',
'                        name,',
'                        username,',
'                        parent_id,',
'                        rownum as ord',
'                    from MITARBEITERS',
'                    start with NVL(UPPER(username), ''-1'') = NVL(v(''SESSION_USER_NAME''), ''-1'')',
'                    connect by nocycle prior name = parent_id',
'                )',
'        ) LOOP',
'            IF TO_CHAR(exists_in.id) = TO_CHAR(:P4_EDIT_ID) THEN',
'                v_right_count := 1;',
'            END IF;',
'        END LOOP;',
'',
'',
'        IF v_right_count = 1 THEN',
'            SELECT',
'                NAME,',
'                STREET,',
'                PLZ,',
'                CITY',
'            INTO v_name, v_street, v_plz, v_city',
'            FROM MITARBEITERS',
'            WHERE',
'                ID = :P4_EDIT_ID;',
'            ',
'            :P4_NAME := v_name;',
'            :P4_PLZ  := v_plz;',
'            :P4_STREET := v_street;',
'            :P4_CITY := v_city;',
'',
'            :P4_ERROR_MESSAGE := ''NO_ERROR'';',
'        ELSE ',
'            :P4_ERROR_MESSAGE := ''NO_PRIVS'';',
'        END IF;',
'    END IF;',
'END;'))
,p_attribute_02=>'P4_EDIT_ID'
,p_attribute_03=>'P4_NAME,P4_STREET,P4_PLZ,P4_CITY,P4_ERROR_MESSAGE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9919086544180005)
,p_name=>'CheckError'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9919127066180006)
,p_event_id=>wwv_flow_api.id(9919086544180005)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setInterval(function(){ ',
'    if($v("P4_ERROR_MESSAGE") == "NO_PRIVS"){',
'        apex.item("P4_NAME").disable();',
'        apex.item("P4_CITY").disable();',
'        apex.item("P4_PLZ").disable();',
'        apex.item("P4_STREET").disable();',
'        $("#EDIT_GRID").css("display", "none");',
'    }',
'}, 1);'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(9919533444180010)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(9681200044200039)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(9919624889180011)
,p_event_id=>wwv_flow_api.id(9919533444180010)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(9919760845180012)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SaveData'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_old_name VARCHAR2(128 CHAR) := '''';',
'BEGIN',
'    IF :P4_EDIT_ID IS NOT NULL THEN',
'        SELECT NAME INTO v_old_name FROM MITARBEITERS WHERE ID = :P4_EDIT_ID;',
'',
'',
'        UPDATE MITARBEITERS',
'         SET ',
'            NAME = :P4_NAME,',
'            STREET = :P4_STREET,',
'            PLZ = :P4_PLZ,',
'            CITY = :P4_CITY',
'        WHERE',
'            ID = :P4_EDIT_ID;',
'',
'        UPDATE MITARBEITERS SET PARENT_ID = :P4_NAME WHERE PARENT_ID = v_old_name;',
'            ',
'        COMMIT;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'You have successfully edited employee!'
);
wwv_flow_api.component_end;
end;
/
