prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9517357508663646
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'RIJAD'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(9848243714542386)
,p_name=>'Seite 1'
,p_alias=>'HOME'
,p_step_title=>'MTAG 2'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'RIJAD'
,p_last_upd_yyyymmddhh24miss=>'20210206172450'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9679083656200017)
,p_plug_name=>'Seite 1'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(9761148638542307)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID,',
'    NAME,',
'    STREET,',
'    PLZ,',
'    CITY',
'FROM MITARBEITERS',
'ORDER BY ID ASC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Seite 1'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(9679132450200018)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF:RTF:EMAIL'
,p_owner=>'RIJAD'
,p_internal_uid=>9679132450200018
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9679209595200019)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9679721075200024)
,p_db_column_name=>'NAME'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9679865944200025)
,p_db_column_name=>'STREET'
,p_display_order=>70
,p_column_identifier=>'C'
,p_column_label=>unistr('Stra\00DFe')
,p_column_type=>'STRING'
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_group VARCHAR2(64 CHAR) := '''';',
'BEGIN',
'    SELECT GROUP_TYPE INTO v_group FROM MITARBEITERS WHERE UPPER(USERNAME) = v(''SESSION_USER_NAME'');',
'',
'    IF v_group = ''ADMINISTRATOR'' THEN ',
'        RETURN TRUE;',
'    END IF;',
'',
'    RETURN FALSE;',
'END;'))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9679992830200026)
,p_db_column_name=>'PLZ'
,p_display_order=>80
,p_column_identifier=>'D'
,p_column_label=>'PLT'
,p_column_type=>'STRING'
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_group VARCHAR2(64 CHAR) := '''';',
'BEGIN',
'    SELECT GROUP_TYPE INTO v_group FROM MITARBEITERS WHERE UPPER(USERNAME) = v(''SESSION_USER_NAME'');',
'',
'    IF v_group = ''ADMINISTRATOR'' THEN ',
'        RETURN TRUE;',
'    END IF;',
'',
'    RETURN FALSE;',
'END;'))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(9680028132200027)
,p_db_column_name=>'CITY'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Stadt'
,p_column_type=>'STRING'
,p_display_condition_type=>'FUNCTION_BODY'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_group VARCHAR2(64 CHAR) := '''';',
'BEGIN',
'    SELECT GROUP_TYPE INTO v_group FROM MITARBEITERS WHERE UPPER(USERNAME) = v(''SESSION_USER_NAME'');',
'',
'    IF v_group = ''ADMINISTRATOR'' THEN ',
'        RETURN TRUE;',
'    END IF;',
'',
'    RETURN FALSE;',
'END;'))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(9865212500578455)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'98653'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NAME:STREET:PLZ:CITY'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9859118533542429)
,p_plug_name=>'MTAG 2'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(9753460202542299)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
